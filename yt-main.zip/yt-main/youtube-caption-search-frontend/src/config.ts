const BASE_URL: string = process.env.VUE_APP_BASE_URL
export { BASE_URL }