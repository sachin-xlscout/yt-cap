<template>
  <v-app>
    <SpinnerCircle v-show="isLoading" />
    <HeaderItem />
    <v-main>
      <router-view />
    </v-main>
    <!-- <FooterItem /> -->
      <v-footer padless class="footer">
    <v-col
      class="text-left"
      cols="6"
    >
      <a class="help-center" target="_blank" href="https://next.xlscout.ai/help">Help Center</a>
    </v-col>
    <v-col
      class="text-right"
      cols="6"
    >
     Copyright © 2020 XLscout. All Rights Reserved
    </v-col>
  </v-footer>
  </v-app>
</template>

<script lang="ts">
import Vue from 'vue';
import SpinnerCircle from '@/components/SpinnerCircle.vue';
// import FooterItem from '@/components/footer.vue';
import HeaderItem from '@/components/Header.vue'
import { mapGetters } from 'vuex';

export default Vue.extend({
  name: 'App',
  data: () => ({}),
  components: { SpinnerCircle,HeaderItem },
  computed: {
    ...mapGetters(['isLoading']),
  },
});
</script>
<style lang="scss">
.footer{
   height: 42px;
  background-color: #e31e29 !important;
  color: #fff !important;
  font-size: 13px;
  // font-family: ;
  padding-left: 26px;
  padding-right: 26px;
  .help-center{
    color: #fff;
    text-decoration: none;
  }
}
</style>
