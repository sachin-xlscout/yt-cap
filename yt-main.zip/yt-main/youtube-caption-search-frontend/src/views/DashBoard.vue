
<template>
  <div class="dashBoard">
    <v-card class="overflow-hidden ma-4" rounded="6" elevation="0">
      <NavBar />
      <v-container>
        <div class="yt__search-form">
          <v-responsive min-width="400" max-width="800">
            <!-- <div class="text-h4 my-4">Youtube Caption Search</div> -->
            <!-- <v-text-field
              outlined
              v-model="domain"
              label="Technology Domain*"
              type="input"
              hint="Enter the Domain Name for the Search"
              color="info"
              class="mt-5"
            ></v-text-field> -->
          <div class="form__input-row">
            <div class="left__part">
            <div class="field__label"><span> Technology Keyword </span></div>
            </div>
            <div class="right__part">
            <v-text-field
              outlined
              v-model="keyword"
              placeholder="Lithium battery OR lithium"
              type="input"
              hint="Enter the Keyword for the search"
              color="info"
            ></v-text-field>
            </div>
            </div>
          <div class="form__input-row">
            <div class="left__part">
            <div class="operator__tag"><span> AND </span></div>
            <div class="field__label">Target Name</div>
            </div>
            <div class="right__part">
                  <v-select
                    placeholder="Intel OR Google"
                    :items="['HP', 'XEROX', 'XEROX CareAr', 'Konica Minolta' ]"
                    outlined
                    color="info"
                    v-model="channelName"
                  ></v-select>
            </div>
            </div>
            <div class="form__input-row">
              <div class="left__part">
              <div class="operator__tag"><span> AND </span></div>
              <div class="field__label">Publication Date</div>
              </div>
              <div class="right__part">
            <div class="d-flex justify-space-between" style="width:100%">
              <v-text-field
                outlined
                v-model="publishedAfter"
                label="Published After"
                type="date"
                color="info"
                class="mr-2"
              ></v-text-field>

              <v-text-field
                outlined
                v-model="publishedBefore"
                label="Publication Before"
                type="date"
                color="info"
                class="ml-2"
              ></v-text-field>
            </div>
            </div>
            </div>
            <div class="d-flex justify-space-between">
              <div></div>
              <v-btn
                class="text-capitalize white--text px-10 right"
                variant="flat"
                color="red"
                large
                @click="getResult"
              >
                Search
              </v-btn>
            </div>
          </v-responsive>
        </div>
      </v-container>
    </v-card>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import NavBar from '@/components/NavBar2.vue';
import {
  searchFirstFifyVideoId,
  searchAllVideoId,
} from '@/services/search.services';

import {
  storeFirstFiftyVideoToElastic,
  storeAllVideoToElastic,
} from '@/services/store.services';

import { fetchVideoCaptionFromElastic } from '@/services/result.services';
import { mapActions, mapGetters, mapMutations } from 'vuex';

export default Vue.extend({
  name: 'DashBoard',

  components: { NavBar },
  data: () => ({
    keyword: '',
    domain: '',
    channelName: '',
    publishedAfter: '',
    publishedBefore: '',
    defOpt: 'AND',
  }),
  computed: {
    ...mapGetters(['isLoading', 'query']),
  },
  methods: {
    ...mapActions(['setVideoList']),
    ...mapMutations(['setIsLoading', 'setQuery', 'setPageLength']),
    async getResult() {
      this.setIsLoading(true);
      const keyword = this.keyword ? this.keyword : '';
      const domain = this.domain ? this.domain : '';
      const channelName = this.channelName ? this.channelName : '';
      const publishedAfter: string = this.publishedAfter
        ? this.publishedAfter.replaceAll('-', '')
        : '';
      const publishedBefore: string = this.publishedBefore
        ? this.publishedBefore.replaceAll('-', '')
        : '';

      const data = {
        keyword,
        domain,
        channelName,
        publishedAfter,
        publishedBefore,
      };
      console.log(data);
      try {
        // add  query data(keyword,domain,channelName,publication date) and first 50 video Id in mongo and wait for it
        const response = await searchFirstFifyVideoId(data);
        if (response.success) {
          //  add all video after 50 in mongo without waiting for it (background Process)
          const { _id, nextPageToken } = response.query;
          searchAllVideoId({ _id, nextPageToken, ...data });

          // store the first 50 video Id caption in elastic and wait for it
          await storeFirstFiftyVideoToElastic(_id);

          // store all video in elastic without waiting for it (background process)
          storeAllVideoToElastic(_id);
        }
        // fetch first 50 video caption from elastic and wait for it
        this.setQuery(this.createQuery());
        console.log(this.query);
        const responseThree = await fetchVideoCaptionFromElastic(
          this.query,
          0,
          20,
          this.defOpt,
        );

        this.setVideoList(responseThree.videoList);
        this.setPageLength(Math.ceil(responseThree.total / 20));

        // now route to the result page and show the result
        this.setIsLoading(false);
        this.$router.push('/result');
         // eslint-disable-next-line
      } catch (error: any) {
        console.log('Some error happened..', error.message);
      }
    },
    createQuery() {
      let query = `(((captions:(${this.keyword})) OR (title:(${this.keyword})))`;
      if (this.channelName) {
        query += ` AND ((channelName.keyword:(${this.channelName})) OR (title:(${this.channelName})) OR (customChannelName.keyword:(${this.channelName})) OR (captions:(${this.channelName})))`;
      }
      if (this.publishedAfter && this.publishedBefore) {
        query += ` AND (publicationDate:[ ${this.publishedAfter.replaceAll(
          '-',
          '',
        )} TO ${this.publishedBefore.replaceAll('-', '')} ])`;
      }
      query += `)`;

      return query;
    },
  },
});
</script>

<style lang='scss'>
.yt__search-form{
  display: flex;
  justify-content: center;
margin-top: 16px;
}
.form__input-row{
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 4px;
  .left__part{
    width: 30%;
    display: flex;
    gap: 12px;
    .field__label{
      padding: 4px;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 45px;
    min-width: 45px;
    width: 100%;
    border: 1px solid #b7b7b7;
    background-color: #ffffff;
    color: #060606;
    border-radius: 5px;
    text-align: left;
    }
  }
  .right__part{
    width: 70%;
    .v-input__slot{
      height: 45px !important;  
      min-height: 45px !important;
    }
  
    
  }
  .operator__tag{
    // border: 1px solid #000;
    border-radius: 5px;
    padding: 4px;
    background-color: #eceef9;
    border: none;
    height: 45px;
    // max-width: fit-content;
    // overflow: hidden;
    min-width: 45px;
    display: flex;
    justify-content: center;
    align-items: center;
    font: bold 13px "Poppins", sans-serif;
    text-align: center !important;
  }
}
</style>
