<template>
  <div class="channelForm">
    <v-card class="overflow-hidden ma-4" rounded="6" elevation="0">
      <NavBar />
      <v-container>
        <div class="d-flex justify-center">
          <v-responsive min-width="400" max-width="800">
            <div class="text-h6 my-4">Caption All video By Channel Id</div>
            <v-text-field
              outlined
              v-model="id"
              label="Channel Id *"
              type="input"
              hint="Enter the Channel Id"
              color="info"
            ></v-text-field>

            <v-text-field
              outlined
              v-model="customName"
              label="Custom Name *"
              type="input"
              hint="Enter the Custom for the search"
              color="info"
            ></v-text-field>
            <div class="d-flex justify-space-between">
              <v-text-field
                outlined
                v-model="publishedAfter"
                label="Publication Date From"
                type="date"
                hint="Please Enter the From date"
                color="info"
                class="mr-2"
              ></v-text-field>

              <v-text-field
                outlined
                v-model="publishedBefore"
                label="Publication Date To"
                type="date"
                hint="Enter the channel id"
                color="info"
                class="ml-2"
              ></v-text-field>
            </div>
            <div class="d-flex justify-space-between">
              <div></div>
              <v-btn
                class="text-capitalize white--text px-10"
                variant="flat"
                color="red"
                large
                @click="uploadVideo"
              >
                Upload
              </v-btn>
            </div>
            <div v-show="showResult" class="text-h6 ma-4">
              Total Video Count : {{ videoCount }}
            </div>

            <div class="d-flex justify-space-between mt-3">
              <div></div>
              <v-btn
                v-show="showResult"
                class="text-capitalize white--text px-10"
                variant="flat"
                color="red"
                large
                @click="indexVideo"
              >
                Index All Video
              </v-btn>
            </div>
          </v-responsive>
        </div>
      </v-container>
    </v-card>
  </div>
</template>
<script lang="ts">
import Vue from 'vue';
import { searchAllVideoByChannelId } from '@/services/search.services';
import { storeAllChannelVideoToElastic } from '@/services/store.services';
import { mapMutations } from 'vuex';
import NavBar from '@/components/NavBar2.vue';

export default Vue.extend({
  components: { NavBar },
  data: () => ({
    id: '',
    customName: '',
    publishedAfter: '',
    publishedBefore: '',
    videoCount: null,
    mongoId: '',
  }),
  computed: {
    showResult() {
      if (this.videoCount) return true;
      if (this.videoCount === 0) return true;
      return false;
    },
  },
  methods: {
    ...mapMutations(['setIsLoading']),
    async uploadVideo() {
      this.setIsLoading(true);
      if (this.publishedBefore) {
        this.publishedBefore = `${this.publishedBefore}T00:00:00Z`;
      }
      if (this.publishedAfter) {
        this.publishedAfter = `${this.publishedAfter}T00:00:00Z`;
      }
      const data = {
        id: this.id,
        customName: this.customName,
        publishedAfter: this.publishedAfter,
        publishedBefore: this.publishedBefore,
      };
      const response = await searchAllVideoByChannelId(data);
      this.videoCount = response.total;
      this.mongoId = response.id;
      console.log(response);
      this.setIsLoading(false);
      this.publishedBefore = this.publishedAfter= ''
    },

    async indexVideo() {
      this.setIsLoading(true);
      const response = await storeAllChannelVideoToElastic(this.mongoId);
      console.log(response);
      this.videoCount = null;
      this.setIsLoading(false);
    },
  },
});
</script>
