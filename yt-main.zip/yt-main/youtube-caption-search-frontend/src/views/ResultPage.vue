<template>
  <div class="resultPage">

      <div class="text-center mt-5">
        <v-pagination
          tile
          v-model="page"
          :length="pageLength"
          color="red"
          @input="fetchData"
        ></v-pagination>
      </div>
      <v-row class="pa-7 d-flex">
        <v-col v-for="(video, index) in videoList" :key="index" cols="12" class="align-self-auto">
          <VideoCard :video='video'/>
        </v-col>
      </v-row>
  </div>
</template>

<script lang="ts">
import { fetchVideoCaptionFromElastic } from '@/services/result.services';
import Vue from 'vue';
import { mapActions, mapGetters, mapMutations } from 'vuex';
import VideoCard from '@/components/VideoCard.vue'

export default Vue.extend({
  data: () => ({
    video: '',
    page: 1,
  }),
  components: {
    VideoCard
  },
  computed: {
    ...mapGetters(['videoList', 'query', 'pageLength']),
  },
  methods: {
    ...mapActions(['setVideoList']),
    ...mapMutations(['setIsLoading']),
    async fetchData() {
      console.log(this.query);
      this.setIsLoading(true);
      const start = 20 * (this.page - 1);
      const end = start + 20;
      const responseThree = await fetchVideoCaptionFromElastic(
        this.query,
        start,
        end,
        'AND',
      );
      this.setVideoList(responseThree.videoList.slice(start,end));
      this.setIsLoading(false);
    },
  },
});
</script>

<style scoped>
.a-link {
  text-decoration: none;
}
.resultPage{
    width:90%;
    margin: 0 auto;
}
</style>
