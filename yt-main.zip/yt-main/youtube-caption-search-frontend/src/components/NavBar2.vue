<template>
  <div >
    <div class="page__header">
        <img src="@/assets/video-search.png"  alt="">
       <div class="heading"> Youtube Caption Search </div>
    </div>
    <div class="page__header-options">
      <button @click="openSearchGuide" class="search__guide-btn"><v-icon style="margin-right:8px" icon="mdi-tooltip-account">mdi-tooltip-account</v-icon>Search Guide</button>
    </div>
  </div>
</template>

<script lang='ts'>
import Vue from 'vue'
export default Vue.extend ({

methods:{
  openSearchGuide(){
    window.open(`https://xlscout-dev.web.app/help`,"_blank")
  }
}

})
</script>

<style lang='scss'>
.page__header{
    display: flex;
    justify-content: center;
    align-items: center;
    img{
        height: 100px;
    }
    .heading{
        font-weight: 800;
    text-align: center;
    color: grey;
    font-size: 2em;
    }
}
.page__header-options{
  display: flex;
  justify-content: flex-end;
  position: relative;
  top: -70px;
  right: 20px;
}
.search__guide-btn{
  background-color: #eceef9;
  border-radius: 5px;
    outline: none;
    color: #060606;
    height: 45px;
    padding: 0 20px;
    box-sizing: border-box;
    display: flex;
    justify-content: flex-start;
    align-items: center;
        width: 100%;
    max-width: 156px;
    overflow: hidden;
    min-width: 45px;
    font: bold 13px "Poppins", sans-serif !important;
    border: 0 !important;
}
</style>