<template>
  <v-app-bar
    color="blue-grey lighten-4"
    dark
    shrink-on-scroll
    prominent
    dense
    tile
    elevation="0"
    fade-img-on-scroll
    scroll-target="#scrolling-techniques-4"
  >
    <v-toolbar-title
      ><v-img
        src="https://next.xlscout.ai/img/xlpatLogo.a6246561.png"
        width="200"
        class="ma-5"
      ></v-img
    ></v-toolbar-title>
    <v-toolbar-title class="mb-6 text-h4 black--text"
      >Youtube Caption Search</v-toolbar-title
    >
  </v-app-bar>
</template>

<script lang="ts">
import Vue from 'vue';
export default Vue.extend({});
</script>
