<template>
  <div class="spinner">
    <v-progress-circular
      :size="100"
      :width="4"
      color="red"
      indeterminate
    ></v-progress-circular>
  </div>
</template>
<script lang="ts">
import Vue from 'vue';
export default Vue.extend({});
</script>

<style scoped>
.spinner {
  position: absolute;
  display: grid;
  place-content: center;
  width: 100%;
  height: 100vh;
  background: rgba(104, 80, 80, 0.267);
  z-index: 999;
}
</style>
