<template>
    <footer class="footer">
     <span  @click="openHelpGuide" class="footer__help-button">
        {{ `help` }}
     </span>
      <span>
      {{ `copyright` }}
    </span>
    </footer>
</template>

<script lang="ts">

import Vue from 'vue';

export default Vue.extend({
    name: 'FooterItem',
   data: () => ({
    // translationPath : 'footer'
  }),
  components: {},
  methods:{
    openHelpGuide(){
      window.open('/help',"_blank")
      }
    }  
  
});
</script>
<style lang='scss'>
.footer {
  height: 42px;
  background-color: #e31e29;
  color: #fff;
  // @include flexible(space-between);
  padding: 0 50px; //$mainSideMargins;

  position: fixed;
  // z-index: -1;
  width: 98.75%;
  // bottom: 0;


}
</style>