<template>
    <v-card
            outlined
            type="success"
            color="blue-grey lighten-5"
            class="pa-2"
            height="100%"
          >
            <v-row class="d-flex flex-no-wrap justify-space-between">
              <v-col cols="8">
                <v-card-title
                  class="text-h6"
                  v-text="video.title"
                ></v-card-title>
                <v-card-subtitle>{{ video.channelName }} | Published on : {{ getDate }}</v-card-subtitle>
               

                 <div class="ma-3">
                  <div v-for="(caption,index) in video.data" :key="index">
                   <a :href="`https://www.youtube.com/watch?v=${video.videoId}&t=${Math.floor(parseInt(caption.timestamp))}`" target="_blank"> {{ caption.timestamp }}</a>
                    :
                    {{ caption.text }}
                  </div>
                </div>
              </v-col>
              <v-col cols="4"> 
              <iframe width="100%" height="100%" :src="iframeLink" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

              </v-col>
            </v-row>
          </v-card>
</template>

<script lang="ts">
import Vue from 'vue'
export default Vue.extend({
    props:['video'],
    data: () => ({
    videoTimestamp:0
    
    }),
    computed:{
    link() {
      return `https://www.youtube.com/watch?v=${this.video.videoId}`;
    },
    iframeLink(){
        return `https://www.youtube.com/embed/${this.video.videoId}?t=${this.videoTimestamp}`
    },
    getDate(){
        if(this.video.publicationDate) return  `${this.video.publicationDate.slice(6,8)}-${this.video.publicationDate.slice(4,6)}-${this.video.publicationDate.slice(0,4)}`
        return ''
    }
    },
    methods:{
     changeTime(time){
        this.videoTimestamp += parseInt(time)
     }
    }
})
</script>