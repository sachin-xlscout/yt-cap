<template>
  <header>
    <div class="header__wrapper">
      <router-link to="/" class="header__menu-button">
        <img src="@/assets/headerMenu.svg" alt="menu">
      </router-link>
    
       <div class="header__controls-bar">
        <img src="@/assets/xlpatLogo.png" alt="logo"  class="header__logo" >
        <!-- <img :src="getImgUrl()" alt="logo" class="header__logo" :class="[!isNovelty && `header__logo--triz`,isInvalidator && `header__logo--inval`]" v-else> -->

        <div class="header__controls-wrapper">
          <!-- <messages></messages> -->
          <!-- <language-dropdown></language-dropdown> -->
          <span class="header__vertical-divider"></span>
          <!-- <user-dropdown></user-dropdown> -->
        </div>
      </div>
      </div>
    <!-- <sub-nav v-if="!isIntro"></sub-nav> -->
  </header>
</template>

<script lang='ts'>
import Vue from "vue"
export default Vue.extend({
name:'HeaderItem'

})
</script>

<style lang='scss'>
.header__wrapper{
    height: 72px;
    margin-top: 24px;
    display: flex;
    .header__menu-button {
    box-shadow: 0px 0px 4px -2px #060606;
    cursor: pointer;
    transition: 0.2s;
    background-color: #eceef9;
    display: block;
    border-radius: 5px;
    outline: none;
    color: #060606;
    text-decoration: none;
    border: none;
    height: 45px;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0 20px;
    box-sizing: border-box;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    font: bold 13px "Poppins", sans-serif;
    width: 100%;
    max-width: 200px;
    overflow: hidden;
    min-width: 45px;
    width: 104px;
    border-radius: 0 5px 5px 0;
    margin-right: 10px;
    height: 72px;
    justify-content: center;
    }
    .header__controls-bar {
    box-shadow: 0px 0px 4px -2px #060606;
    border-radius: 5px 0 0 5px;
    width: calc(100% - 104px - 10px);
    background-color: #eceef9;
    height: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .header__logo {
    margin-left: 27px;
    height: 24px !important;
}
    }
}
</style>