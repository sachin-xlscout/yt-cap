import Vue from 'vue'
import VueRouter, { RouteConfig } from 'vue-router'
import DashBoard from '@/views/DashBoard.vue'
import ResultPage from '@/views/ResultPage.vue'
import ChannelForm from '@/views/ChannelForm.vue'

Vue.use(VueRouter)

const routes: Array<RouteConfig> = [
    {
        path: '/',
        name: 'dashboard',
        component: DashBoard
    },
    {
        path: '/result',
        name: 'result',
        component: ResultPage
    },
    {
        path: '/channel/upload',
        name: 'channelform',
        component: ChannelForm
    }

]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router
