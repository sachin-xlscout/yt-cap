import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)


export default new Vuex.Store({
    state: {
        videoList: [],
        isLoading: false,
        query: '',
        pageLength: 1
    },
    getters: {
        videoList: state => state.videoList,
        isLoading: state => state.isLoading,
        query: state => state.query,
        pageLength: state => state.pageLength

    },
    mutations: {
        setVideoList: (state, videoList) => {
            state.videoList = videoList
        },
        setIsLoading: (state, isLoading) => {
            state.isLoading = isLoading
        },
        setQuery: (state, query) => {
            state.query = query
        },
        setPageLength: (state, pageLength) => {
            state.pageLength = pageLength
        }
    },
    actions: {
        setVideoList({ commit }, payload) {
            commit('setVideoList', payload)
        }
    },
    modules: {
    }
})
