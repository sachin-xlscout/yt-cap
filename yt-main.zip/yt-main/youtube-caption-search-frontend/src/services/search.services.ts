/* eslint-disable */
import axios from "axios";

type reqDataFirst = {
    keyword: string,
    domain: string,
    channelId?: string,
    publishedAfter?: string | Date,
    publishedBefore?: string | Date,
    relatedToVideoId?: string,

}
type reqDataSecond = {
    keyword: string,
    domain: string,
    channelId?: string,
    publishedAfter?: string | Date,
    publishedBefore?: string | Date,
    relatedToVideoId?: string,
    _id: string,
    nextPageToken: string
}

type reqDataChannel = {
    id: string,
    customName: string,
    publishedAfter: string,
    publishedBefore: string,
}

const searchFirstFifyVideoId = async (data: reqDataFirst): Promise<any> => {
    const payload = {
        method: 'post',
        url: '/search/videoId',
        data
    }
    try {
        const { data } = await axios(payload)
        if (!data.success) throw data
        return data
    } catch (error: any) {
        console.error('Some Error happened while Search First Fifty Video Id..')
        return error
    }
}

const searchAllVideoId = async (data: reqDataSecond): Promise<any> => {
    console.log(data)
    const payload = {
        method: 'post',
        url: '/search/appendId',
        data
    }
    try {
        const { data } = await axios(payload)
        if (!data.success) throw data
        return data
    } catch (error: any) {
        console.error('Some Error happened while Search All Video Id..')
        return error
    }
}

const searchAllVideoByChannelId = async (data: reqDataChannel): Promise<any> => {
    const payload = {
        method: 'post',
        url: '/search/channel',
        data
    }
    try {
        console.log(payload)
        const { data } = await axios(payload)
        if (!data.success) throw data
        return data
    } catch (error: any) {
        console.error('Some Error happened while Search All Video Id of Channel..')
        return error
    }
}

export {
    searchAllVideoId, searchFirstFifyVideoId, searchAllVideoByChannelId
}