/* eslint-disable */
import axios from "axios";

const fetchVideoCaptionFromElastic = async (query: string, skip: number, limit: number, defOpt: string) => {
    const payload = {
        method: 'post',
        url: '/result',
        data: {
            query, skip, limit, defOpt
        }
    }
    try {
        const { data } = await axios(payload)
        if (!data.success) throw data
        return data
    } catch (error: any) {
        console.error('Some Error happened Fetching the Video From Elastic..')
        return error
    }
}

export {
    fetchVideoCaptionFromElastic
}