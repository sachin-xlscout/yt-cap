/* eslint-disable */
import axios from "axios";

const storeFirstFiftyVideoToElastic = async (_id: string) => {
    const payload = {
        method: 'post',
        url: `/store/${_id}`
    }
    try {
        const { data } = await axios(payload)
        if (!data.success) throw data
        return data
    } catch (error: unknown) {
        console.error('Some Error happened while Storing First Fifty Videos..')
        return error
    }
}

const storeAllVideoToElastic = async (_id: string) => {
    const payload = {
        method: 'post',
        url: `/store/all/${_id}`
    }
    try {
        const { data } = await axios(payload)
        if (!data.success) throw data
        return data
    } catch (error: any) {
        console.error('Some Error happened while Storing All Videos..')
        return error
    }
}
const storeAllChannelVideoToElastic = async (_id: string) => {
    const payload = {
        method: 'post',
        url: `/store/channel/${_id}`
    }
    try {
        const { data } = await axios(payload)
        if (!data.success) throw data
        return data
    } catch (error: any) {
        console.error('Some Error happened while Storing All Videos Of Channel..')
        return error
    }
}



export {
    storeFirstFiftyVideoToElastic,
    storeAllVideoToElastic,
    storeAllChannelVideoToElastic
}